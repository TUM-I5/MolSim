// file      : xsd/cxx/pre.hxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#ifdef _MSC_VER
#  if (_MSC_VER >= 1400)
#    include <xsd/cxx/compilers/vc-8/pre.hxx>
#  else
#    error Microsoft Visual C++ 7.1 and earlier are not supported
#  endif
#endif
