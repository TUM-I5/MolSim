// file      : xsd/cxx/compilers/vc-8/post.hxx
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#pragma warning (pop)
